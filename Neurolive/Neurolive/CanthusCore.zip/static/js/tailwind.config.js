tailwind.config = {
    theme: {
        extend: {
            colors: {
                slate: { 50: '#D0ECF9', 100: '#D0ECF9', 200: '#4BA8D6', 300: '#4BA8D6', 400: '#505C77', 500: '#2C3970', 600: '#163166', 700: '#163166', 800: '#0D1C3D', 900: '#0D1C3D' },
                sky: { 300: '#4BA8D6', 400: '#2885B5', 500: '#2243AA' },
                blue: { 50: '#D0ECF9', 100: '#D0ECF9', 400: '#4BA8D6', 500: '#2885B5', 600: '#2243AA', 700: '#163166' }
            },
            fontFamily: {
                sans: ['Avenir', 'Avenir Next', 'sans-serif'],
                serif: ['Adobe Caslon', 'Adobe Caslon Pro', 'serif'],
                mono: ['Courier New', 'monospace'],
            }
        }
    }
}
