from pydantic import BaseModel
from typing import List
from enum import Enum

class AlertSeverity(str, Enum):
    WARNING = "WARNING"
    FLAGGED = "FLAGGED"
    CRITICAL = "CRITICAL"

class ActiveAlert(BaseModel):
    code: str
    severity: AlertSeverity
    message: str
    timestamp: float
    points: int

class HeadPose(BaseModel):
    yaw: float
    pitch: float
    roll: float

class IrisRatios(BaseModel):
    h: float
    v: float

class ProctoringMetrics(BaseModel):
    face_count: int
    head_pose: HeadPose
    iris_ratios: IrisRatios
    vad_speech_prob: float

