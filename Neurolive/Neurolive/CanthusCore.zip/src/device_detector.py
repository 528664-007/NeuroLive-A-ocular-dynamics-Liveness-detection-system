from ultralytics import YOLO

from typing import List, Dict, Any, Tuple

class DeviceDetector:
    def __init__(self, model_path: str = 'yolov8n.pt', conf_threshold: float = 0.25):
        self.model = YOLO(model_path)
        self.conf_threshold = conf_threshold
        # COCO Classes mapping:
        # 67: 'cell phone', 63: 'laptop', 73: 'book'
        self.prohibited_class_names = ["cell phone", "laptop", "book"]
        
        # Build set of target class IDs dynamically based on the model's names mapping
        self.target_class_ids = set()
        for idx, name in self.model.names.items():
            if name in self.prohibited_class_names:
                self.target_class_ids.add(idx)

    def process_frame(self, frame) -> Tuple[List[Dict[str, Any]], bool]:
        """
        Process the frame using YOLOv8.
        Returns:
            - List of detected objects with box, class name, and confidence.
            - Boolean flag indicating if any prohibited device was detected.
        """
        results = self.model(frame, verbose=False)[0]
        detected_objects = []
        is_prohibited_detected = False

        for box in results.boxes:
            conf = float(box.conf[0])
            cls_id = int(box.cls[0])
            
            if conf >= self.conf_threshold and cls_id in self.target_class_ids:
                class_name = self.model.names[cls_id]
                is_prohibited_detected = True
                
                # Bounding box coordinates [x1, y1, x2, y2]
                xyxy = box.xyxy[0].tolist()
                
                detected_objects.append({
                    "class": class_name,
                    "confidence": conf,
                    "box": xyxy
                })
                
        return detected_objects, is_prohibited_detected
