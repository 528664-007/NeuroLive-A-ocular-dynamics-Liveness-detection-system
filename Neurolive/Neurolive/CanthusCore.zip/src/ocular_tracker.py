import math
import numpy as np
import cv2

class OneEuroFilter:
    def __init__(self, min_cutoff=1.0, beta=0.007, d_cutoff=1.0):
        self.min_cutoff = min_cutoff
        self.beta = beta
        self.d_cutoff = d_cutoff
        self.x_prev = None
        self.dx_prev = None
        self.t_prev = None

    def smoothing_factor(self, t_e, cutoff):
        r = 2 * math.pi * cutoff * t_e
        return r / (r + 1)

    def exponential_smoothing(self, a, x, x_prev):
        return a * x + (1 - a) * x_prev

    def __call__(self, x, t):
        x = np.array(x, dtype=float)
        if self.t_prev is None:
            self.x_prev = x
            self.dx_prev = np.zeros_like(x)
            self.t_prev = t
            return x

        t_e = t - self.t_prev
        if t_e <= 0:
            return self.x_prev

        dx = (x - self.x_prev) / t_e
        a_d = self.smoothing_factor(t_e, self.d_cutoff)
        dx_hat = self.exponential_smoothing(a_d, dx, self.dx_prev)

        # Dynamic cutoff based on derivative (velocity) magnitude
        velocity_mag = np.linalg.norm(dx_hat)
        cutoff = self.min_cutoff + self.beta * velocity_mag
        a = self.smoothing_factor(t_e, cutoff)
        x_hat = self.exponential_smoothing(a, x, self.x_prev)

        self.x_prev = x_hat
        self.dx_prev = dx_hat
        self.t_prev = t
        return x_hat


class HeadPoseEstimator:
    def __init__(self):
        # Canonical 3D Face Model (based on standard IPD of ~63mm)
        # 1: Nose, 152: Chin, 33: Left Eye Corner, 263: Right Eye Corner, 61: Left Mouth, 291: Right Mouth
        self.canonical_3d = np.array([
            (0.0, 0.0, 0.0),             # Nose tip (1)
            (0.0, 50.0, -10.0),          # Chin (152) - Positive Y is DOWN
            (-31.5, -30.0, -15.0),       # Left eye (33) - Negative Y is UP
            (31.5, -30.0, -15.0),        # Right eye (263)
            (-20.0, 20.0, -10.0),        # Left mouth (61)
            (20.0, 20.0, -10.0)          # Right mouth (291)
        ], dtype=np.float64)
        
        self.landmarks_indices = [1, 152, 33, 263, 61, 291]
        self.cam_matrix = None
        self.dist_matrix = np.zeros((4, 1), dtype=np.float64)

    def process(self, landmarks, w, h):
        if self.cam_matrix is None:
            focal_length = w
            self.cam_matrix = np.array([
                [focal_length, 0, w / 2],
                [0, focal_length, h / 2],
                [0, 0, 1]
            ], dtype=np.float64)

        image_points = np.array([
            [landmarks[idx].x * w, landmarks[idx].y * h] for idx in self.landmarks_indices
        ], dtype=np.float64)

        # Adaptive Anthropometric Scaling (optional refinement based on dynamic facial bounding box could go here)
        # Using Levenberg-Marquardt (SOLVEPNP_ITERATIVE)
        success, rvec, _ = cv2.solvePnP(
            self.canonical_3d, 
            image_points, 
            self.cam_matrix, 
            self.dist_matrix, 
            flags=cv2.SOLVEPNP_ITERATIVE
        )

        if not success:
            return 0.0, 0.0, 0.0
            
        rmat, _ = cv2.Rodrigues(rvec)
        angles, _, _, _, _, _ = cv2.RQDecomp3x3(rmat)
        
        pitch = angles[0]
        yaw = angles[1]
        roll = angles[2]
        return yaw, pitch, roll


class OcularGeometryTracker:
    def __init__(self):
        # Left eye: [left canthus, right canthus, top lid, bottom lid, iris]
        self.left_idx = [33, 133, 159, 145, 468]
        # Right eye: [left canthus, right canthus, top lid, bottom lid, iris]
        self.right_idx = [362, 263, 386, 374, 473]

    def _extract_eye_metrics(self, landmarks, indices, w, h):
        c_left = np.array([landmarks[indices[0]].x * w, landmarks[indices[0]].y * h])
        c_right = np.array([landmarks[indices[1]].x * w, landmarks[indices[1]].y * h])
        l_top = np.array([landmarks[indices[2]].x * w, landmarks[indices[2]].y * h])
        l_bot = np.array([landmarks[indices[3]].x * w, landmarks[indices[3]].y * h])
        iris = np.array([landmarks[indices[4]].x * w, landmarks[indices[4]].y * h])

        width = np.linalg.norm(c_right - c_left)
        height = np.linalg.norm(l_bot - l_top)
        
        # Horizontal Iris-to-Canthus Ratio (ICR)
        icr = np.linalg.norm(iris - c_left) / width if width > 0 else 0.5
        
        # Vertical Palpebral Fissure Margin (Iris to top lid relative to eye height)
        vpm = np.linalg.norm(iris - l_top) / height if height > 0 else 0.5
        
        # True Scale-Invariant Eye Aspect Ratio (EAR)
        ear = height / width if width > 0 else 0.5
        
        # Glare / Occlusion confidence proxy (if iris falls outside eye bounds, confidence drops)
        confidence = 1.0
        if icr < -0.1 or icr > 1.1 or vpm < -0.1 or vpm > 1.1:
            confidence = 0.0
            
        return icr, vpm, confidence, ear

    def process(self, landmarks, w, h):
        # 478 points needed for iris
        if len(landmarks) < 474:
            return 0.5, 0.5, 0.5, 0.0

        l_icr, l_vpm, l_conf, l_ear = self._extract_eye_metrics(landmarks, self.left_idx, w, h)
        r_icr, r_vpm, r_conf, r_ear = self._extract_eye_metrics(landmarks, self.right_idx, w, h)

        # Dual-Eye Glare Fallback
        if l_conf > 0.5 and r_conf < 0.5:
            # Right eye obscured/glare, mirror left
            r_icr = l_icr
            r_vpm = l_vpm
        elif r_conf > 0.5 and l_conf < 0.5:
            # Left eye obscured, mirror right
            l_icr = r_icr
            l_vpm = r_vpm

        # Refraction Normalization (adaptive scaling could be applied here by comparing eye widths against canonical model)
        # Average both eyes for robust tracking
        avg_vpm = (l_vpm + r_vpm) / 2.0
        avg_ear = (l_ear + r_ear) / 2.0
        
        return l_icr, r_icr, avg_vpm, avg_ear
