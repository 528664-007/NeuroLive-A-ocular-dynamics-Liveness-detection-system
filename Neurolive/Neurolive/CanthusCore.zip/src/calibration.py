import numpy as np
import json
import os

class GazeCalibrator:
    def __init__(self, config_path="gaze_calib.json"):
        self.config_path = config_path
        self.points = []       # Target Screen (X, Y)
        self.features = []     # (IL, IR, IV, Yaw, Pitch)
        
        # Polynomial Coefficients
        self.c_x = None
        self.c_y = None

    def add_point(self, screen_x, screen_y, l_icr, r_icr, vpm, yaw, pitch):
        self.points.append([screen_x, screen_y])
        self.features.append([l_icr, r_icr, vpm, yaw, pitch])

    def _build_poly_features(self, X):
        """
        Builds a linear multivariate feature matrix.
        X shape: (N, 5) -> [IL, IR, IV, Yaw, Pitch]
        Returns shape: (N, 6)
        """
        N = X.shape[0]
        IL = X[:, 0]
        IR = X[:, 1]
        IV = X[:, 2]
        Yaw = X[:, 3]
        Pitch = X[:, 4]
        
        # 6-term linear regression (safe for 9 calibration points without overfitting)
        return np.column_stack([
            np.ones(N),
            IL, IR, IV, Yaw, Pitch
        ])

    def calibrate(self):
        # Expect ~150 points over 15 seconds at 10 FPS. Require at least 100 valid frames.
        if len(self.points) < 100:
            return False
            
        Y = np.array(self.points)
        X = np.array(self.features)
        
        A = self._build_poly_features(X)
        
        # Solve Ax = b for X and Y separately using Least Squares
        # A * c_x = Y[:, 0]
        c_x, _, _, _ = np.linalg.lstsq(A, Y[:, 0], rcond=None)
        c_y, _, _, _ = np.linalg.lstsq(A, Y[:, 1], rcond=None)
        
        self.c_x = c_x
        self.c_y = c_y
        
        # Save to disk
        self.save_coefficients()
        return True

    def predict(self, l_icr, r_icr, vpm, yaw, pitch):
        if self.c_x is None or self.c_y is None:
            # Fallback if uncalibrated
            return 0.0, 0.0
            
        X = np.array([[l_icr, r_icr, vpm, yaw, pitch]])
        A = self._build_poly_features(X)
        
        pred_x = np.dot(A, self.c_x)[0]
        pred_y = np.dot(A, self.c_y)[0]
        
        return pred_x, pred_y

    def save_coefficients(self):
        data = {
            "c_x": self.c_x.tolist() if self.c_x is not None else None,
            "c_y": self.c_y.tolist() if self.c_y is not None else None
        }
        with open(self.config_path, "w") as f:
            json.dump(data, f)

    def load_coefficients(self):
        if os.path.exists(self.config_path):
            with open(self.config_path, "r") as f:
                data = json.load(f)
                if data.get("c_x") and data.get("c_y"):
                    self.c_x = np.array(data["c_x"])
                    self.c_y = np.array(data["c_y"])
                    return True
        return False
