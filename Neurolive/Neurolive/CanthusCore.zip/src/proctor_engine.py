import cv2
import mediapipe as mp
import time
import threading
import queue
import torch
import sounddevice as sd
import urllib.request
import os
from mediapipe.tasks import python
from mediapipe.tasks.python import vision

# Import the new NeuroLive Pro Modules
from src.ocular_tracker import HeadPoseEstimator, OcularGeometryTracker, OneEuroFilter
from src.calibration import GazeCalibrator
from src.anomaly_engine import ProctoringStateEngine
from src.alert_engine import AlertManager, AlertCode
from src.device_detector import DeviceDetector

class AudioProctor:
    def __init__(self, sample_rate=16000):
        self.sample_rate = sample_rate
        self.model, utils = torch.hub.load(repo_or_dir='snakers4/silero-vad', model='silero_vad', trust_repo=True)
        self.model.eval()
        _ = utils
        
        self.audio_queue = queue.Queue()
        self.is_running = False
        self.audio_thread = None
        self.current_prob = 0.0

    def audio_callback(self, indata, frames, time_info, status):
        if status:
            pass
        self.audio_queue.put(indata.copy())

    def _process_audio(self):
        while self.is_running:
            try:
                chunk = self.audio_queue.get(timeout=0.1)
                audio_tensor = torch.from_numpy(chunk).squeeze(-1).float()
                if audio_tensor.shape[0] < 512:
                    continue
                prob = self.model(audio_tensor, self.sample_rate).item()
                self.current_prob = prob
            except queue.Empty:
                continue
            except Exception as e:
                print(f"Audio processing error: {e}")

    def start(self, use_local_mic=True):
        self.is_running = True
        self.audio_thread = threading.Thread(target=self._process_audio, daemon=True)
        self.audio_thread.start()
        
        if use_local_mic:
            self.stream = sd.InputStream(samplerate=self.sample_rate, channels=1, blocksize=512, callback=self.audio_callback)
            self.stream.start()

    def stop(self):
        self.is_running = False
        if hasattr(self, 'stream'):
            self.stream.stop()
            self.stream.close()
        if self.audio_thread:
            self.audio_thread.join()

    def get_speech_prob(self):
        return self.current_prob

class ProctoringOrchestrator:
    def __init__(self):
        # 1. Initialize MediaPipe (replacing the old VisionProctor)
        task_path = "face_landmarker.task"
        if not os.path.exists(task_path):
            urllib.request.urlretrieve(
                "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task",
                task_path
            )
        base_options = python.BaseOptions(model_asset_path=task_path)
        options = vision.FaceLandmarkerOptions(
            base_options=base_options,
            output_face_blendshapes=False,
            output_facial_transformation_matrixes=True,
            num_faces=5
        )
        self.detector = vision.FaceLandmarker.create_from_options(options)
        
        # 2. Audio Subsystem
        self.audio = AudioProctor()
        
        # 3. Inject NeuroLive Pro Modules
        self.head_pose = HeadPoseEstimator()
        self.ocular_tracker = OcularGeometryTracker()
        self.calibrator = GazeCalibrator()
        self.alert_manager = AlertManager()
        self.anomaly_engine = ProctoringStateEngine(self.alert_manager)
        self.device_detector = DeviceDetector()
        
        self.filter_x = OneEuroFilter(min_cutoff=1.0, beta=0.007)
        self.filter_y = OneEuroFilter(min_cutoff=1.0, beta=0.007)

        # State
        self.state = "IDLE"  # IDLE, CALIBRATING, PROCTORING
        
        # We handle AUDIO_DETECTED manually here, anomaly_engine handles the rest
        self.speech_start_time = None
        self.GRACE_SPEECH = 0.8
        self.SPEECH_THRESHOLD = 0.65

    def start(self, use_local_mic=True):
        self.audio.start(use_local_mic=use_local_mic)

    def stop(self):
        self.audio.stop()
        
    def start_calibration(self):
        self.state = "CALIBRATING"
        self.calibrator.points = []
        self.calibrator.features = []
        
        # Reset 1Euro filters
        self.filter_x = OneEuroFilter(min_cutoff=1.0, beta=0.007)
        self.filter_y = OneEuroFilter(min_cutoff=1.0, beta=0.007)
        
    def finish_calibration(self):
        success = self.calibrator.calibrate()
        if success:
            self.state = "PROCTORING"
            # Reset the liveness blink timer upon successful calibration
            self.anomaly_engine.liveness.last_blink_time = time.time()
        else:
            # If calibration fails (not enough points), trigger recalibration automatically after a 5s cooldown
            self.state = "RECALIBRATION_COOLDOWN"
            self.cooldown_start = time.time()

    def process_step(self, frame, calib_pt=None):
        current_time = time.time()
        
        # Process Video Frame
        h, w, _ = frame.shape
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
        results = self.detector.detect(mp_image)
        
        face_count = len(results.face_landmarks) if results.face_landmarks else 0
        
        # Defaults
        gaze_x, gaze_y = 0.5, 0.5
        yaw, pitch, roll = 0.0, 0.0, 0.0
        vpm, ear = 0.5, 0.25
        gaze_status = "CENTER"
        mesh_points = []
        
        self.alert_manager.clear_active()
        
        if self.state == "RECALIBRATION_COOLDOWN":
            if current_time - self.cooldown_start > 5.0:
                self.start_calibration()
            else:
                countdown = max(1, 5 - int(current_time - self.cooldown_start))
                self.alert_manager.trigger(AlertCode.CALIBRATION_FAILED, current_time, countdown=countdown)

        # A. DEVICE DETECTION
        detected_devices, is_prohibited = self.device_detector.process_frame(frame)
        if is_prohibited:
            self.alert_manager.trigger(
                AlertCode.PROHIBITED_DEVICE_DETECTED, 
                current_time
            )

        if face_count > 0:
            landmarks = results.face_landmarks[0]
            
            # Extract mesh points for UI overlay (if needed)
            for landmark in landmarks:
                mesh_points.append((int(landmark.x * w), int(landmark.y * h)))
                
            # 1. Head Pose (IPD-scaled Levenberg-Marquardt PnP)
            yaw, pitch, roll = self.head_pose.process(landmarks, w, h)
            
            # 2. Ocular Geometry (ICR, VPM, EAR with Glare Fallback)
            l_icr, r_icr, vpm, ear = self.ocular_tracker.process(landmarks, w, h)
            
            # 3. Calibration
            if self.state == "CALIBRATING" and face_count == 1:
                # If we received the red dot coordinate from the frontend websocket
                if calib_pt is not None:
                    # calib_pt is (norm_x, norm_y)
                    self.calibrator.add_point(calib_pt[0], calib_pt[1], l_icr, r_icr, vpm, yaw, pitch)
                
            # 4. Proctoring (Machine-Learning Gaze Mapping & 1Euro Filtering)
            elif self.state == "PROCTORING" and face_count == 1:
                # Predict raw screen coordinates
                raw_gx, raw_gy = self.calibrator.predict(l_icr, r_icr, vpm, yaw, pitch)
                
                # Apply 1 Euro Filter
                gaze_x = self.filter_x(raw_gx, current_time)
                gaze_y = self.filter_y(raw_gy, current_time)
                
                # Pass features to Anomaly Engine (Saccades, Phone Glance, Liveness, Bounds)
                needs_recalibration = self.anomaly_engine.process_frame(face_count, gaze_x, gaze_y, vpm, ear)
                
                if needs_recalibration:
                    self.anomaly_engine.liveness.last_blink_time = current_time
                    self.start_calibration()
                
                # Check if looking away (GAZE_OUT_OF_BOUNDS is triggered)
                active_codes = [a.code for a in self.alert_manager.get_active_list()]
                if AlertCode.GAZE_OUT_OF_BOUNDS in active_codes:
                    gaze_status = "AWAY"
        
        elif self.state == "PROCTORING" and face_count != 1:
            # Anomaly engine handles Multi-face / No-face grace periods
            needs_recalibration = self.anomaly_engine.process_frame(face_count, gaze_x, gaze_y, vpm, ear)
            
            if needs_recalibration:
                self.anomaly_engine.liveness.last_blink_time = current_time
                self.start_calibration()
                
            gaze_status = "AWAY"

        # Audio Proctoring
        audio_prob = self.audio.get_speech_prob()
        if audio_prob > self.SPEECH_THRESHOLD:
            if self.speech_start_time is None:
                self.speech_start_time = current_time
            elif current_time - self.speech_start_time > self.GRACE_SPEECH:
                self.alert_manager.trigger(AlertCode.AUDIO_DETECTED, current_time)
        else:
            self.speech_start_time = None
            
        self.alert_manager.decay_risk(current_time)
        
        # Prepare active alerts for frontend (serialize objects to dicts)
        active_alerts_payload = [alert.dict() for alert in self.alert_manager.get_active_list()]
            
        # Compile payload
        payload = {
            "timestamp": current_time,
            "state": self.state,
            "session_state": self.alert_manager.session_state.value,
            "face_count": face_count,
            "gaze_status": gaze_status,
            "audio_detected": any(a.code == AlertCode.AUDIO_DETECTED for a in self.alert_manager.get_active_list()),
            "active_alerts": active_alerts_payload,
            "risk_score": round(self.alert_manager.risk_score, 2),
            "head_pose": (yaw, pitch, roll),
            "gaze_x": float(gaze_x),
            "gaze_y": float(gaze_y),
            "audio_prob": audio_prob,
            "devices": detected_devices
        }
        
        # Override metrics if still calibrating or on cooldown
        if self.state in ["CALIBRATING", "RECALIBRATION_COOLDOWN"]:
            payload["face_count"] = 0
            payload["gaze_status"] = "-"
            payload["gaze_x"] = 0.0
            payload["gaze_y"] = 0.0
            
        return payload, mesh_points
