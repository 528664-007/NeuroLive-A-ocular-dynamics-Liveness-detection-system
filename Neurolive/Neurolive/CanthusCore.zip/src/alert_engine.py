import time
from enum import Enum
from typing import Dict, List
from pydantic import BaseModel
from src.schemas import AlertSeverity, ActiveAlert

class AlertCode(str, Enum):
    # Visual & Gaze
    GAZE_OUT_OF_BOUNDS = "GAZE_OUT_OF_BOUNDS"
    DOWNWARD_PHONE_GLANCE = "DOWNWARD_PHONE_GLANCE"
    PERIPHERAL_PEEKING_BURST = "PERIPHERAL_PEEKING_BURST"
    FACE_OCCLUSION = "FACE_OCCLUSION"
    
    # Presence & Identity
    CANDIDATE_ABSENT = "CANDIDATE_ABSENT"
    MULTIPLE_PEOPLE = "MULTIPLE_PEOPLE"
    IMPERSONATION_DETECTED = "IMPERSONATION_DETECTED"
    
    # Acoustic & Audio
    AUDIO_DETECTED = "AUDIO_DETECTED"
    
    # System Lockdown & Environment
    FOCUS_LOST = "FOCUS_LOST"
    FORBIDDEN_PROCESS_RUNNING = "FORBIDDEN_PROCESS_RUNNING"
    SECONDARY_DISPLAY_ATTACHED = "SECONDARY_DISPLAY_ATTACHED"
    SHORTCUT_ATTEMPT = "SHORTCUT_ATTEMPT"
    
    # Liveness & Calibration
    LIVENESS_CHECK_FAILED = "LIVENESS_CHECK_FAILED"
    CALIBRATION_FAILED = "CALIBRATION_FAILED"
    PROHIBITED_DEVICE_DETECTED = "PROHIBITED_DEVICE_DETECTED"

class SessionState(str, Enum):
    NORMAL = "NORMAL"
    CAUTION = "CAUTION"
    HIGH_RISK = "HIGH_RISK"
    CRITICAL = "CRITICAL"

class AlertDefinition(BaseModel):
    code: AlertCode
    severity: AlertSeverity
    message_template: str
    points: int
    cooldown: float = 3.0  # Seconds before the same alert can add points again

# The global catalog mapping codes to their definitions
ALERT_CATALOG = {
    AlertCode.GAZE_OUT_OF_BOUNDS: AlertDefinition(
        code=AlertCode.GAZE_OUT_OF_BOUNDS,
        severity=AlertSeverity.WARNING,
        message_template="Please keep your eyes focused on your screen. (Count: {count})",
        points=10,
        cooldown=2.0
    ),
    AlertCode.DOWNWARD_PHONE_GLANCE: AlertDefinition(
        code=AlertCode.DOWNWARD_PHONE_GLANCE,
        severity=AlertSeverity.FLAGGED,
        message_template="Looking down detected. Please ensure all devices and notes are out of view.",
        points=25,
        cooldown=5.0
    ),
    AlertCode.PERIPHERAL_PEEKING_BURST: AlertDefinition(
        code=AlertCode.PERIPHERAL_PEEKING_BURST,
        severity=AlertSeverity.FLAGGED,
        message_template="Repeated sideways glances detected. Please stay centered on the exam.",
        points=20,
        cooldown=5.0
    ),
    AlertCode.FACE_OCCLUSION: AlertDefinition(
        code=AlertCode.FACE_OCCLUSION,
        severity=AlertSeverity.WARNING,
        message_template="Face partially covered. Please keep your full face visible to the camera.",
        points=15
    ),
    AlertCode.CANDIDATE_ABSENT: AlertDefinition(
        code=AlertCode.CANDIDATE_ABSENT,
        severity=AlertSeverity.CRITICAL,
        message_template="No face detected in frame. Please return to the camera view immediately.",
        points=50,
        cooldown=5.0
    ),
    AlertCode.MULTIPLE_PEOPLE: AlertDefinition(
        code=AlertCode.MULTIPLE_PEOPLE,
        severity=AlertSeverity.CRITICAL,
        message_template="Multiple people detected in the camera frame. Unauthorized assistance is prohibited.",
        points=60,
        cooldown=5.0
    ),
    AlertCode.IMPERSONATION_DETECTED: AlertDefinition(
        code=AlertCode.IMPERSONATION_DETECTED,
        severity=AlertSeverity.CRITICAL,
        message_template="Biometric identity verification failed. A live proctor has been summoned.",
        points=100
    ),
    AlertCode.AUDIO_DETECTED: AlertDefinition(
        code=AlertCode.AUDIO_DETECTED,
        severity=AlertSeverity.WARNING,
        message_template="Audio detected in the room. Please maintain a quiet environment.",
        points=15,
        cooldown=4.0
    ),
    AlertCode.FOCUS_LOST: AlertDefinition(
        code=AlertCode.FOCUS_LOST,
        severity=AlertSeverity.FLAGGED,
        message_template="Exam window lost focus! Switching away from the exam environment is recorded as a violation.",
        points=30,
        cooldown=5.0
    ),
    AlertCode.FORBIDDEN_PROCESS_RUNNING: AlertDefinition(
        code=AlertCode.FORBIDDEN_PROCESS_RUNNING,
        severity=AlertSeverity.CRITICAL,
        message_template="Restricted background application detected. Please terminate unauthorized programs.",
        points=80
    ),
    AlertCode.SECONDARY_DISPLAY_ATTACHED: AlertDefinition(
        code=AlertCode.SECONDARY_DISPLAY_ATTACHED,
        severity=AlertSeverity.CRITICAL,
        message_template="Secondary display detected. Please unplug all external monitors to proceed.",
        points=90
    ),
    AlertCode.SHORTCUT_ATTEMPT: AlertDefinition(
        code=AlertCode.SHORTCUT_ATTEMPT,
        severity=AlertSeverity.WARNING,
        message_template="Keyboard shortcut blocked. Clipboard and developer tools are disabled.",
        points=10,
        cooldown=2.0
    ),
    AlertCode.LIVENESS_CHECK_FAILED: AlertDefinition(
        code=AlertCode.LIVENESS_CHECK_FAILED,
        severity=AlertSeverity.CRITICAL,
        message_template="Liveness Check Failed - Recalibrating in {countdown}s",
        points=30,
        cooldown=5.0 # Match the 5s countdown timer exactly
    ),
    AlertCode.PROHIBITED_DEVICE_DETECTED: AlertDefinition(
        code=AlertCode.PROHIBITED_DEVICE_DETECTED,
        severity=AlertSeverity.CRITICAL,
        message_template="Prohibited electronic device detected!",
        points=70,
        cooldown=3.5
    ),
    AlertCode.CALIBRATION_FAILED: AlertDefinition(
        code=AlertCode.CALIBRATION_FAILED,
        severity=AlertSeverity.WARNING,
        message_template="Screen limit calibration failed. Recalibrating in 5 seconds...",
        points=0,
        cooldown=10.0
    )
}

class AlertManager:
    def __init__(self):
        self.risk_score: float = 0.0
        self.session_state: SessionState = SessionState.NORMAL
        self.active_alerts: Dict[str, ActiveAlert] = {}
        self.last_trigger_times: Dict[str, float] = {}
        self.event_counts: Dict[str, int] = {}
        self.last_decay_time: float = time.time()
        
    def trigger(self, code: AlertCode, timestamp: float, **kwargs) -> None:
        """
        Triggers an alert. If it's outside the cooldown, it accumulates points.
        Kwargs are passed to the message template formatter.
        """
        if code not in ALERT_CATALOG:
            return
            
        defn = ALERT_CATALOG[code]
        last_time = self.last_trigger_times.get(code, 0)
        
        # Increment count if it's a new occurrence (past cooldown) or never occurred
        if timestamp - last_time > defn.cooldown:
            self.event_counts[code] = self.event_counts.get(code, 0) + 1
            self.risk_score = min(100.0, self.risk_score + defn.points)
            self.last_trigger_times[code] = timestamp
            self._update_state()
            
        kwargs['count'] = self.event_counts.get(code, 1)
        
        # Format the message
        try:
            message = defn.message_template.format(**kwargs)
        except KeyError:
            message = defn.message_template # Fallback if kwargs don't match
            
        # Add to currently active alerts for this frame
        self.active_alerts[code] = ActiveAlert(
            code=code,
            severity=defn.severity,
            message=message,
            timestamp=timestamp,
            points=defn.points
        )

    def decay_risk(self, current_time: float = None):
        """Passively reduce risk score when no alerts are active."""
        if current_time is None:
            current_time = time.time()
        
        dt = current_time - self.last_decay_time
        if len(self.active_alerts) == 0:
            self.risk_score = max(0.0, self.risk_score - (1.5 * dt))
            self._update_state()
            
        self.last_decay_time = current_time
        
    def _update_state(self):
        if self.risk_score >= 80:
            self.session_state = SessionState.CRITICAL
        elif self.risk_score >= 50:
            self.session_state = SessionState.HIGH_RISK
        elif self.risk_score >= 20:
            self.session_state = SessionState.CAUTION
        else:
            self.session_state = SessionState.NORMAL
            
    def clear_active(self):
        """Called at the beginning of a processing step to clear the transient active list."""
        self.active_alerts.clear()
        
    def reset_session(self):
        """Reset state and counts when a new session starts."""
        self.risk_score = 0.0
        self.session_state = SessionState.NORMAL
        self.active_alerts.clear()
        self.last_trigger_times.clear()
        self.event_counts.clear()
        self.last_decay_time = time.time()
        
    def get_active_list(self) -> List[ActiveAlert]:
        return list(self.active_alerts.values())
