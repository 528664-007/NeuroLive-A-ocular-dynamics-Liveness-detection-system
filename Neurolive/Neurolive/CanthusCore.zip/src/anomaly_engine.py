import time
import numpy as np
from collections import deque
from src.alert_engine import AlertCode

class SaccadeAnalyzer:
    def __init__(self, window_ms=500, saccade_threshold=300.0):
        # Sliding window for angular velocity (degrees/sec equivalent or px/ms)
        self.window_ms = window_ms
        self.saccade_threshold = saccade_threshold
        self.history = deque() # tuples of (timestamp, gaze_x, gaze_y)
        
    def process(self, gaze_x, gaze_y, current_time):
        self.history.append((current_time, gaze_x, gaze_y))
        
        # Purge old data
        while self.history and (current_time - self.history[0][0]) * 1000 > self.window_ms:
            self.history.popleft()
            
        if len(self.history) < 2:
            return 0.0, False
            
        # Calculate max velocity in the window
        max_vel = 0.0
        for i in range(1, len(self.history)):
            dt = self.history[i][0] - self.history[i-1][0]
            if dt <= 0: continue
            
            dx = self.history[i][1] - self.history[i-1][1]
            dy = self.history[i][2] - self.history[i-1][2]
            dist = np.sqrt(dx**2 + dy**2)
            
            vel = dist / dt # Units per second
            if vel > max_vel:
                max_vel = vel
                
        is_anomalous_saccade = max_vel > self.saccade_threshold
        return max_vel, is_anomalous_saccade


class PhoneGlanceDetector:
    def __init__(self, down_threshold=0.75, grace_period=1.0):
        self.down_threshold = down_threshold
        self.grace_period = grace_period
        self.down_start_time = None
        
    def process(self, vpm, current_time):
        # High Vertical Palpebral Margin (VPM) means iris is closer to bottom lid (looking down)
        if vpm > self.down_threshold:
            if self.down_start_time is None:
                self.down_start_time = current_time
            elif (current_time - self.down_start_time) > self.grace_period:
                return True
        else:
            self.down_start_time = None
            
        return False


class OcularLivenessDetector:
    def __init__(self, min_duration=0.1, max_duration=0.6):
        # Normal blink is 100ms - 400ms, but allowing up to 600ms for slow blinks
        self.min_duration = min_duration
        self.max_duration = max_duration
        self.blink_start = None
        self.last_blink_time = time.time()
        self.ear_threshold = 0.25 # EAR drops below this during a blink
        
    def process(self, ear, current_time):
        if ear < self.ear_threshold:
            if self.blink_start is None:
                self.blink_start = current_time
        else:
            if self.blink_start is not None:
                duration = current_time - self.blink_start
                self.blink_start = None
                
                # Valid human blink?
                if self.min_duration <= duration <= self.max_duration:
                    self.last_blink_time = current_time
                    
        # We no longer strictly return True/False here, 
        # we will handle the exact timing in ProctoringStateEngine.
        return current_time - self.last_blink_time


class ProctoringStateEngine:
    def __init__(self, alert_manager):
        self.alert_manager = alert_manager
        self.saccade = SaccadeAnalyzer()
        self.phone = PhoneGlanceDetector()
        self.liveness = OcularLivenessDetector()
        
        # Off-screen Gaze Buffers
        self.off_screen_start = None
        self.off_screen_grace = 1.2 # seconds
        self.is_looking_away = False
        
        # Face absence
        self.absence_start = None
        self.absence_grace = 1.5 # seconds
        
        # Multi-face
        self.multi_start = None
        self.multi_grace = 0.5 # seconds

    def process_frame(self, face_count, gaze_x, gaze_y, vpm, ear):
        t = time.time()
        
        # 1. Face Count Anomalies
        if face_count == 0:
            if self.absence_start is None:
                self.absence_start = t
            elif (t - self.absence_start) > self.absence_grace:
                self.alert_manager.trigger(AlertCode.CANDIDATE_ABSENT, t)
        else:
            self.absence_start = None
            
        if face_count > 1:
            if self.multi_start is None:
                self.multi_start = t
            elif (t - self.multi_start) > self.multi_grace:
                self.alert_manager.trigger(AlertCode.MULTIPLE_PEOPLE, t)
        else:
            self.multi_start = None
            
        if face_count != 1:
            return

        # 2. Gaze Out-of-Bounds
        margin = 0.05
        # Normalized screen bounds (0 to 1). We allow a 5% margin of error.
        if (gaze_x < -margin or gaze_x > 1.0 + margin or 
            gaze_y < -margin or gaze_y > 1.0 + margin):
            
            if self.off_screen_start is None:
                self.off_screen_start = t
            elif (t - self.off_screen_start) > self.off_screen_grace:
                if not self.is_looking_away:
                    self.is_looking_away = True
                self.alert_manager.trigger(AlertCode.GAZE_OUT_OF_BOUNDS, t)
        else:
            self.off_screen_start = None
            self.is_looking_away = False

        # 3. Phone Glance (Downward)
        if self.phone.process(vpm, t):
            self.alert_manager.trigger(AlertCode.DOWNWARD_PHONE_GLANCE, t)
            
        # 4. Saccadic Velocity
        max_vel, is_anomalous = self.saccade.process(gaze_x, gaze_y, t)
        if is_anomalous:
            # Saccade itself isn't immediately an alert, but it flags suspicion
            pass

        # 5. Liveness
        time_since_blink = self.liveness.process(ear, t)
        if time_since_blink > 30.0:
            countdown = max(1, 5 - int(time_since_blink - 30.0))
            self.alert_manager.trigger(AlertCode.LIVENESS_CHECK_FAILED, t, countdown=countdown)
            
            # If 5 seconds have elapsed, trigger recalibration
            if time_since_blink > 35.0:
                # We can't trigger RECALIBRATION as an alert code because it's an action, 
                # so we will add it to the active alerts manually or return it.
                # Actually, AlertManager doesn't handle action flags.
                # Let's return a boolean from process_frame to indicate recalibration is needed.
                return True
                
        return False

