from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import Request
import uvicorn
import cv2
import numpy as np
import base64
import time
from src.proctor_engine import ProctoringOrchestrator
from src.alert_engine import AlertCode

app = FastAPI(title="NeuroLive - Real-Time Proctoring")

# Static files and Templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Initialize global engine
orchestrator = ProctoringOrchestrator()
orchestrator.start(use_local_mic=False)  # We'll feed audio from WS, not local mic

@app.on_event("shutdown")
def shutdown_event():
    orchestrator.stop()

@app.get("/", response_class=HTMLResponse)
async def welcome(request: Request):
    return templates.TemplateResponse(request=request, name="welcome.html")

@app.get("/proctor", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(request=request, name="index.html")

@app.post("/report_client_event/{event_name}")
async def report_client_event(event_name: str):
    current_time = time.time()
    
    if event_name == "FOCUS_LOST":
        orchestrator.alert_manager.trigger(AlertCode.FOCUS_LOST, current_time)
    elif event_name == "SHORTCUT_ATTEMPT":
        orchestrator.alert_manager.trigger(AlertCode.SHORTCUT_ATTEMPT, current_time)
        
    return {"status": "success", "event": event_name}

@app.websocket("/ws/proctor")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    
    # Reset alert manager state on new connection (refresh)
    orchestrator.alert_manager.reset_session()
    
    try:
        while True:
            message = await websocket.receive_json()
            
            if "command" in message:
                cmd = message["command"]
                if cmd == "start_calibration":
                    orchestrator.start_calibration()
                elif cmd == "finish_calibration":
                    orchestrator.finish_calibration()
            
            payload = {}
            mesh_points = []
            
            # Handle Video
            if "video" in message:
                video_data = message["video"].split(",")[1]
                decoded_data = base64.b64decode(video_data)
                np_data = np.frombuffer(decoded_data, np.uint8)
                frame = cv2.imdecode(np_data, cv2.IMREAD_COLOR)
                
                if frame is not None:
                    # Extract calibration point if it exists
                    calib_pt = None
                    if "calib_x" in message and "calib_y" in message:
                        calib_pt = (message["calib_x"], message["calib_y"])
                        
                    # Process step
                    payload, mesh_points = orchestrator.process_step(frame, calib_pt=calib_pt)
            
            # Handle Audio
            if "audio" in message:
                # Assuming audio is a list of floats (PCM f32le)
                audio_array = np.array(message["audio"], dtype=np.float32)
                # Reshape to (N, 1) to match sounddevice indata shape
                audio_array = audio_array.reshape(-1, 1)
                orchestrator.audio.audio_queue.put(audio_array)

            if payload:
                await websocket.send_json({
                    "type": "telemetry",
                    "payload": payload,
                    "mesh_points": mesh_points
                })
                
    except WebSocketDisconnect:
        print("Client disconnected.")
    except Exception as e:
        print(f"WebSocket error: {e}")

if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
